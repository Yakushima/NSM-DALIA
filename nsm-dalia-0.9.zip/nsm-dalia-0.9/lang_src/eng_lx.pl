:- include('../bin/operators.pl').

ct(v(v),say(X)) ::: p(say,[e,e,e,e,e],[a:e,o:X,d:e,t:e]).

m(v(v),"lie",say(lie)).
